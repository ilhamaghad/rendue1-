# gestion des evenemnets
une application qui permet au utilisateurs de gerer des reservations d'un evenemnet precis des terrins , des salles et dajouter supprimer modifer  des utilisateurs des salles ... et de voir la disponibilite d'une salle ou d'un terrain .

## fonctionnalites

### 1. **gestion des utilisateurs**
   - Ajout, modifier et supprimer  des utilisateurs 
   - Les utilisateurs a eux comme informations   l'identifiant, le nom, le prenom, l'e-mail et le type (Etudiant ou Professeur)

### 2. **Gestion des evenements**
   - ajouter un evenement  avec un nom, une date, une description et un utilisateur associe.
   - Modifier et supprimer  des evenements existants.

### 3. **Gestion des terrains et des salles**
   - Ajout de terrains avec un type  et un nom et un identuifiant
   - Ajout de salles avec un nom et une capacite 

### 4. **Gestion des reservations**
   - Les utilisateurs peuvent reserver des evenements avec un terrain et une salle.
   - Modifier et supprimer des reservations existantes deja 

## Prérequis

 les prérequis utiliser pour coder cette application  :

- **Java JDK 17** 
- **PostgreSQL** 
- **JDBC PostgreSQL Driver** 


