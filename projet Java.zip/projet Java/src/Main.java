package src;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
 String type_user;
 int id_user;
 String nom, prenom, email, nom_event, nom_terrain, nom_salle;
 String url = "jdbc:postgresql://localhost:5432/gestion_events";
 String username = "postgres";
 String password = "ilham123";

 try {
 Class.forName("org.postgresql.Driver");
 try (Connection conn = DriverManager.getConnection(url, username, password);
   Statement statement = conn.createStatement()) {
  System.out.println("Connexion reussie");
  Scanner sc = new Scanner(System.in);
  System.out.println(" ------Bienvenue a notre application de gestion des evenements :-------");
  System.out.println("*********INSERTION************");
  System.out.println("Saisir votre identifiant ");
  id_user = sc.nextInt();
  sc.nextLine();
  System.out.println("Saisir votre nom : ");
  nom = sc.nextLine();
  System.out.println("Saisir votre prenom :");
  prenom = sc.nextLine();
  System.out.println("Saisir votre email ");
  email = sc.nextLine();
  System.out.println("Est-ce que vous etes un Etudiant ou un Professeur ?");
  type_user = sc.nextLine();
  String query_user = String.format("INSERT INTO users (id_user, nom, prenom, email, type) VALUES (%d, '%s', '%s', '%s', '%s')", id_user, nom, prenom, email, type_user);
  statement.executeUpdate(query_user);
  System.out.println(nom + " " + prenom + " a ete insere avec succes");
  System.out.println("Evenement____ :");
  System.out.println("Saisir l identifiant de l'evenement :");
  int id_event = sc.nextInt();
  sc.nextLine();
  System.out.println("Saisir le nom d'evenement :");
  nom_event = sc.nextLine();
   System.out.println("Saisir la date d'evenement :");
 String date_event = sc.nextLine();
 SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
 java.sql.Date sqlDateEvent = null;
 try {
     java.util.Date parsedDateEvent = sdf.parse(date_event);
     sqlDateEvent = new java.sql.Date(parsedDateEvent.getTime());
 } catch (ParseException e) {
     System.out.println("Erreur de format de la date de l'événement : " + e.getMessage());
     return;
 }
  System.out.println("Saisir une description del'evenement :");
  String description = sc.nextLine();
  String query_event = String.format("INSERT INTO events (id_event, nom_event, date_event, descripssion, id_user) VALUES (%d, '%s', '%s', '%s', %d)", id_event, nom_event , sqlDateEvent , description , id_user );
  statement.executeUpdate(query_event);
  System.out.println(nom_event+ " a ete insere avec succes");
  System.out.println("Terrain____ :");
  System.out.println("Saisir l identifiant de Terrain :");
  int id_terrain = sc.nextInt();
  sc.nextLine();
  System.out.println("Saisir le nom de Terrain :");
  nom_terrain = sc.nextLine();
  System.out.println("Saisir le type de terrain :");
  String terrain_type = sc.nextLine();
  String query_terrain = String.format("INSERT INTO terrains (id_terrain, nom_terrain, terrain_type) VALUES (%d, '%s', '%s')", id_terrain, nom_terrain , terrain_type);
  statement.executeUpdate(query_terrain);
  System.out.println(nom_terrain+ " a ete insere avec succes");
  System.out.println("Salle_____ :");
  System.out.println("Saisir l'identifiant de la salle :");
  int id_salle = sc.nextInt();
  sc.nextLine();
  System.out.println("Saisir le nom de salle:");
  nom_salle = sc.nextLine();
  System.out.println("Saisir la capacite de la salle :");
  int capacite = sc.nextInt();
  String query_salle = String.format("INSERT INTO salles (id_salle, nom_salle, capacite) VALUES (%d, '%s', %d)", id_salle, nom_salle , capacite);
  statement.executeUpdate(query_salle);
  System.out.println(nom_salle + " a ete insere avec succes");
  System.out.println("___RESERVATION : ______");
   System.out.println("Saisir votre date de reservation : ");
 sc.nextLine();
 String date_reservation = sc.nextLine();
 SimpleDateFormat sdfReservation = new SimpleDateFormat("dd/MM/yy");
 java.sql.Date sqlDateReservation = null;
 try {
     java.util.Date parsedDateReservation = sdfReservation.parse(date_reservation);
     sqlDateReservation = new java.sql.Date(parsedDateReservation.getTime());
 } catch (ParseException e) {
     System.out.println("Erreur de format de la date de réservation : " + e.getMessage());
     return;
 }
  String query_reservation = String.format("INSERT INTO reservation (id_user, id_event, id_salle, id_terrain, date_reservation ) VALUES (%d, %d, %d, %d, '%s')", id_user, id_event , id_salle , id_terrain , sqlDateReservation);
  statement.executeUpdate(query_reservation);
  System.out.println("Reservation reussie");
  System.out.println("***** MODIFICATION *****");
  System.out.println("Voulez-vous modifier un utilisateur, un evenement, ou une reservation ?");
  String modifier = sc.nextLine();
  if (modifier.equals("utilisateur")) {
  System.out.println("Modifier un Utilisateur : ");
  System.out.println("Saisir l'ID de l'utilisateur a modifier :");
  int id_user_updated = sc.nextInt();
  sc.nextLine(); 
  System.out.println("Saisir le nouveau nom de l'utilisateur :");
  String new_nom = sc.nextLine();
  System.out.println("Saisir le nouveau prenom de l'utilisateur :");
  String new_prenom = sc.nextLine();
  System.out.println("Saisir le nouvel email de l'utilisateur :");
  String new_email = sc.nextLine();
  System.out.println("Saisir le type de l'utilisateur :");
  String new_type = sc.nextLine();
  String updateQuery = "UPDATE users SET nom = '" + new_nom + "', prenom = '" + new_prenom + "', email = '" + new_email + "', type = '" + new_type + "' WHERE id_user = " + id_user_updated;
  int rowsAffected = statement.executeUpdate(updateQuery);
  if (rowsAffected > 0) {
   System.out.println("L'utilisateur avec l'ID " + id_user_updated + " a ete mis a jour avec succees !");
  } else {
   System.out.println("Aucun utilisateur trouve avec l'ID " + id_user_updated);
  }
  } else if (modifier.equals("evenement")) {
  System.out.println("Modifier un Evenement : ");
  System.out.println("Saisir l'ID de l'evenement a modifier :");
  int id_event_updated = sc.nextInt();
  sc.nextLine(); 
  System.out.println("Saisir le nouveau nom de l'evenement :");
  String new_event_nom = sc.nextLine();
System.out.println("Saisir la nouvelle date de l'evenement (au format dd/MM/yy) :");
String new_date_event = sc.nextLine();

java.sql.Date newSqlDate = null;

SimpleDateFormat sdfUpdate = new SimpleDateFormat("dd/MM/yy");  

try {
    java.util.Date newParsedDate = sdfUpdate.parse(new_date_event);
    newSqlDate = new java.sql.Date(newParsedDate.getTime());
    System.out.println("Date convertie avec succes : " + newSqlDate);
} catch (ParseException e) {
    System.out.println("Erreur de format de date veuillez entrer la date au format dd/MM/yy.");
    e.printStackTrace();
}
System.out.println("Saisir la nouvelle description de l'evenement :");
String new_event_description = sc.nextLine();

if (newSqlDate != null) {
    String updateEventQuery = "UPDATE events SET nom_event = '" + new_event_nom + "', date_event = '" + newSqlDate + "', descripssion = '" + new_event_description + "' WHERE id_event = " + id_event_updated;
    
    int eventRowsAffected = statement.executeUpdate(updateEventQuery);
    if (eventRowsAffected > 0) {
        System.out.println("L'evenement avec l'ID " + id_event_updated + " a ete mis a jour avec succes !");
    } else {
        System.out.println("aucun evenement trouve avec l'ID " + id_event_updated);
    }
} else {
    System.out.println("La date fournie n'est pas valide la mise a jour a echoue");
}
  } else if (modifier.equals("reservation")) {
  System.out.println("Modifier une Reservation : ");
  System.out.println("Saisir l'ID de la reservation a modifier :");
  int id_reservation_updated = sc.nextInt();
  sc.nextLine(); 
System.out.println("Saisir la nouvelle date de reservation (au format dd/MM/yy) :");
String new_reservation_date = sc.nextLine();

java.sql.Date newSqlReservationDate = null;

SimpleDateFormat sdfReservationUpdate = new SimpleDateFormat("dd/MM/yy");

try {
    java.util.Date newParsedReservationDate = sdfReservationUpdate.parse(new_reservation_date);
    newSqlReservationDate = new java.sql.Date(newParsedReservationDate.getTime());
    System.out.println("Nouvelle date de reservation convertie avec succes : " + newSqlReservationDate);
} catch (ParseException e) {
    System.out.println("Erreur de format de date veuillez entrer la date au format dd/MM/yy.");
    e.printStackTrace();
}
if (newSqlReservationDate != null) {
    String updateReservationQuery = "UPDATE reservation SET date_reservation = '" + newSqlReservationDate + "' WHERE id_reservation = " + id_reservation_updated;

    int reservationRowsAffected = statement.executeUpdate(updateReservationQuery);
    if (reservationRowsAffected > 0) {
        System.out.println("La reservation avec l'ID " + id_reservation_updated + " a ete mise a jour avec succes !");
    } else {
        System.out.println("Aucune reservation trouvee avec l'ID " + id_reservation_updated);
    }
} else {
    System.out.println("La date fournie n'est pas valide la mise a jour a echoue");
}
  }
  System.out.println("*******SUPPRESSION*******");
  System.out.println("Voulez-vous supprimer un utilisateur, un evenement, ou une reservation ?");
  String supprimer = sc.nextLine();
  if (supprimer.equals("utilisateur")) {
  System.out.println("Saisir l'ID de l'utilisateur à supprimer :");
  int id_user_deleted = sc.nextInt();
  sc.nextLine(); 
  String deleteQuery = "DELETE FROM users WHERE id_user = " + id_user_deleted;
  int rowsDeleted = statement.executeUpdate(deleteQuery);
  if (rowsDeleted > 0) {
   System.out.println("L'utilisateur avec l'ID " + id_user_deleted + " a ete supprime avec succes !");
  } else {
   System.out.println("Aucun utilisateur trouve avec l'ID " + id_user_deleted);
  }
  } else if (supprimer.equals("evenement")) {
  System.out.println("Saisir l'ID de l'evenement a supprimer :");
  int id_event_deleted = sc.nextInt();
  sc.nextLine(); 
String deleteReservationsQuery = "DELETE FROM reservation WHERE id_event = " + id_event_deleted;
int reservationsDeleted = statement.executeUpdate(deleteReservationsQuery);
if (reservationsDeleted > 0) {
    System.out.println("Les reservations associees a l'evenement ont ete supprimees.");
} else {
    System.out.println("Aucune reservation associee a cet evenement.");
}
String deleteEventQuery = "DELETE FROM events WHERE id_event = " + id_event_deleted;
int eventRowsDeleted = statement.executeUpdate(deleteEventQuery);
if (eventRowsDeleted > 0) {
    System.out.println("L'evenement avec l'ID " + id_event_deleted + " a ete supprime avec succes ");
} else {
    System.out.println("Aucun evenement trouve avec l'ID " + id_event_deleted);
}
  } else if (supprimer.equals("reservation")) {
  System.out.println("Saisir l'ID de la reservation à supprimer :");
  int id_reservation_deleted = sc.nextInt();
  sc.nextLine(); 
  String deleteReservationQuery = "DELETE FROM reservation WHERE id_reservation = " + id_reservation_deleted;
  int reservationRowsDeleted = statement.executeUpdate(deleteReservationQuery);
  if (reservationRowsDeleted > 0) {
   System.out.println("La reservation avec l'ID " + id_reservation_deleted + " a ete supprimee avec succes !");
  } else {
   System.out.println("Aucune reservation trouvee avec l'ID " + id_reservation_deleted);
  }
  }
 } catch (SQLException e) {
  e.printStackTrace();
 }
 } catch (ClassNotFoundException e) {
 e.printStackTrace();
 }
}
}
